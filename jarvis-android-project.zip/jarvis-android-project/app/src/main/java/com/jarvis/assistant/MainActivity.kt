package com.jarvis.assistant

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import com.jarvis.assistant.presentation.JarvisScreen
import com.jarvis.assistant.speech.SpeechManager
import com.jarvis.assistant.ai.AIManager
import com.jarvis.assistant.tools.*

class MainActivity : ComponentActivity() {
    private lateinit var speechManager: SpeechManager
    private lateinit var aiManager: AIManager
    
    // UYARI: OpenAI API anahtarınızı buraya yazınız.
    private val OPENAI_API_KEY = "BURAYA_API_ANAHTARINIZI_YAZIN"
    
    private val registeredTools = listOf(GetTimeTool(), GetBatteryStatusTool(), OpenAppTool())
    private var assistantState by mutableStateOf("HAZIR")
    private var lastSpokenText by mutableStateOf("")
    private var lastResponseText by mutableStateOf("Sisteme hoş geldiniz efendim.")

    private val requestPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
        if (isGranted) startVoiceRecognition()
        else { lastResponseText = "Mikrofon izni gereklidir efendim."; speechManager.speak(lastResponseText) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        aiManager = AIManager(OPENAI_API_KEY)
        speechManager = SpeechManager(
            context = this,
            onResult = { text -> lastSpokenText = text; processCommand(text) },
            onError = { error -> lastResponseText = error; speechManager.speak(error) },
            onStateChanged = { state -> assistantState = state }
        )
        speechManager.speak(lastResponseText)
        setContent {
            JarvisScreen(assistantState = assistantState, lastSpokenText = lastSpokenText, lastResponseText = lastResponseText, onMicClick = { checkAndRequestAudioPermission() })
        }
    }

    private fun checkAndRequestAudioPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startVoiceRecognition()
        } else {
            requestPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun startVoiceRecognition() {
        assistantState = "DİNLİYORUM"
        speechManager.startListening()
    }

    private fun processCommand(command: String) {
        lifecycleScope.launch {
            try {
                assistantState = "DÜŞÜNÜYORUM"
                val response = aiManager.processUserCommand(command, registeredTools, this@MainActivity) { newState -> assistantState = newState }
                lastResponseText = response
                speechManager.speak(response)
            } catch (e: Exception) {
                lastResponseText = "Sistemlerimde bir hata oluştu efendim."
                speechManager.speak(lastResponseText)
            } finally {
                assistantState = "HAZIR"
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        speechManager.destroy()
    }
}