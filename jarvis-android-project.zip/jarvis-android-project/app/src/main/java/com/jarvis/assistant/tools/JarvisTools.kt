package com.jarvis.assistant.tools

import android.content.Context
import android.content.Intent
import android.os.BatteryManager
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

interface JarvisTool {
    val name: String
    val description: String
    val parametersSchema: JSONObject
    fun execute(args: JSONObject, context: Context): String
}

class GetTimeTool : JarvisTool {
    override val name = "get_current_time"
    override val description = "Mevcut sistem saatini ve tarihini döndürür."
    override val parametersSchema = JSONObject().apply { put("type", "object"); put("properties", JSONObject()) }
    override fun execute(args: JSONObject, context: Context): String {
        val sdf = SimpleDateFormat("dd MMMM yyyy EEEE, HH:mm", Locale("tr", "TR"))
        return "Şu anki tarih ve saat: ${sdf.format(Date())}"
    }
}

class GetBatteryStatusTool : JarvisTool {
    override val name = "get_battery_status"
    override val description = "Cihazın mevcut pil yüzdesini döndürür."
    override val parametersSchema = JSONObject().apply { put("type", "object"); put("properties", JSONObject()) }
    override fun execute(args: JSONObject, context: Context): String {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        return "Pil seviyesi: %${bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)}"
    }
}

class OpenAppTool : JarvisTool {
    override val name = "open_app"
    override val description = "Uygulama açar (whatsapp, spotify, youtube vb.)"
    override val parametersSchema = JSONObject().apply {
        put("type", "object")
        put("properties", JSONObject().apply {
            put("app_name", JSONObject().apply { put("type", "string"); put("description", "Açılacak uygulama adı") })
        })
        put("required", org.json.JSONArray().put("app_name"))
    }
    override fun execute(args: JSONObject, context: Context): String {
        val appName = args.optString("app_name", "").lowercase(Locale("tr", "TR"))
        val pkg = when {
            appName.contains("whatsapp") -> "com.whatsapp"
            appName.contains("spotify") -> "com.spotify.music"
            appName.contains("youtube") -> "com.google.android.youtube"
            appName.contains("ayarlar") -> "com.android.settings"
            else -> return "Hata: Uygulama bulunamadı."
        }
        return try {
            val intent = context.packageManager.getLaunchIntentForPackage(pkg)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                "Başarılı: $appName açıldı."
            } else "Uygulama yüklü değil."
        } catch (e: Exception) { "Açılamadı." }
    }
}