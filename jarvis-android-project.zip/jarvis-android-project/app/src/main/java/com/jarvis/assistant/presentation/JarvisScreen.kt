package com.jarvis.assistant.presentation

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun JarvisScreen(
    assistantState: String,
    lastSpokenText: String,
    lastResponseText: String,
    onMicClick: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val scale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (assistantState == "DİNLİYORUM") 1.25f else 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF0B0F19)) {
        Column(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Spacer(modifier = Modifier.height(32.dp))
                Text("J.A.R.V.I.S.", color = Color(0xFF00E5FF), fontSize = 28.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
                Text(assistantState, color = Color(0xFF8A99AD), fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp))
            }

            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(220.dp)) {
                Box(modifier = Modifier.size(160.dp * scale).clip(CircleShape).background(Brush.radialGradient(listOf(Color(0xFF00E5FF).copy(alpha = 0.3f), Color.Transparent))))
                Box(modifier = Modifier.size(120.dp).clip(CircleShape).border(2.dp, Color(0xFF00E5FF), CircleShape).background(Color(0xFF111E30)), contentAlignment = Alignment.Center) {
                    IconButton(onClick = onMicClick, modifier = Modifier.size(80.dp)) {
                        Icon(Icons.Default.Mic, contentDescription = "Mikrofon", tint = Color(0xFF00E5FF), modifier = Modifier.size(36.dp))
                    }
                }
            }

            Column(modifier = Modifier.fillMaxWidth().padding(bottom = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                if (lastSpokenText.isNotEmpty()) {
                    Text("Siz: \"$lastSpokenText\"", color = Color(0xFFCFD8DC), fontSize = 14.sp, modifier = Modifier.padding(bottom = 8.dp))
                }
                if (lastResponseText.isNotEmpty()) {
                    Text("JARVIS: \"$lastResponseText\"", color = Color(0xFF00E5FF), fontSize = 16.sp, fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}