package com.jarvis.assistant.ai

import android.content.Context
import android.util.Log
import com.jarvis.assistant.tools.JarvisTool
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class AIManager(private val apiKey: String) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private val systemPrompt = """
        Senin adın JARVIS. Sen Türkçe konuşan, son derece zeki, profesyonel, sakin ve hafif esprili bir kişisel yapay zeka asistanısın.
        Kullanıcıya daima saygılı davran ve gerektiğinde ona "Efendim" diye hitap et.
        Kısa, net ve doğal cevaplar ver. Asla robotik veya sıkıcı konuşma.
        Eğer kullanıcı bir eylem istiyorsa, sana sağlanan araçları (tools) kullan.
    """.trimIndent()

    private val conversationHistory = JSONArray().apply {
        put(JSONObject().apply {
            put("role", "system")
            put("content", systemPrompt)
        })
    }

    suspend fun processUserCommand(
        command: String,
        availableTools: List<JarvisTool>,
        context: Context,
        onStateChange: (String) -> Unit
    ): String = withContext(Dispatchers.IO) {
        if (apiKey.isEmpty() || apiKey == "BURAYA_API_ANAHTARINIZI_YAZIN") {
            return@withContext "Efendim, yapay zekâ servisine bağlanabilmem için geçerli bir API anahtarına ihtiyacım var."
        }
        conversationHistory.put(JSONObject().apply {
            put("role", "user")
            put("content", command)
        })

        val toolsArray = JSONArray()
        availableTools.forEach { tool ->
            toolsArray.put(JSONObject().apply {
                put("type", "function")
                put("function", JSONObject().apply {
                    put("name", tool.name)
                    put("description", tool.description)
                    put("parameters", tool.parametersSchema)
                })
            })
        }

        try {
            return@withContext makeApiRequest(toolsArray, availableTools, context, onStateChange)
        } catch (e: Exception) {
            return@withContext "Bağlantıda bir sorun oluştu efendim."
        }
    }

    private suspend fun makeApiRequest(
        toolsArray: JSONArray,
        availableTools: List<JarvisTool>,
        context: Context,
        onStateChange: (String) -> Unit
    ): String {
        val requestBody = JSONObject().apply {
            put("model", "gpt-4o-mini")
            put("messages", conversationHistory)
            if (toolsArray.length() > 0) {
                put("tools", toolsArray)
                put("tool_choice", "auto")
            }
        }

        val request = Request.Builder()
            .url("https://api.openai.com/v1/chat/completions")
            .addHeader("Authorization", "Bearer $apiKey")
            .post(requestBody.toString().toRequestBody("application/json".toMediaType()))
            .build()

        val response = client.newCall(request).execute()
        if (!response.isSuccessful) throw Exception("Sunucu Hatası")

        val responseData = response.body?.string() ?: throw Exception("Boş yanıt")
        val jsonResponse = JSONObject(responseData)
        val choice = jsonResponse.getJSONArray("choices").getJSONObject(0)
        val message = choice.getJSONObject("message")

        conversationHistory.put(message)

        if (message.has("tool_calls")) {
            onStateChange("İŞLEM YAPILIYOR")
            val toolCalls = message.getJSONArray("tool_calls")
            for (i in 0 until toolCalls.length()) {
                val toolCall = toolCalls.getJSONObject(i)
                val function = toolCall.getJSONObject("function")
                val functionName = function.getString("name")
                val arguments = JSONObject(function.getString("arguments"))
                
                val toolToExecute = availableTools.find { it.name == functionName }
                val toolResultString = toolToExecute?.execute(arguments, context) ?: "Hata: Araç bulunamadı."

                conversationHistory.put(JSONObject().apply {
                    put("role", "tool")
                    put("tool_call_id", toolCall.getString("id"))
                    put("name", functionName)
                    put("content", toolResultString)
                })
            }
            onStateChange("DÜŞÜNÜYORUM")
            return makeApiRequest(toolsArray, availableTools, context, onStateChange)
        } else {
            return message.getString("content")
        }
    }
}